/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package windows;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author victor velandia
 */
public class UserDao {

    public boolean createUser(String password, String user, String userName, String userLastName, int docTypeId, String docNumber, int rolId, int jobId) {
        Connection connection = ConnectionBD.getConnection();
        try {
            Statement stmt = connection.createStatement();
            
            String sql = "INSERT INTO `login` (`User`, `Password`) VALUES ('4', '"+user+"', '"+password+"')";
            stmt.executeUpdate(sql);
            
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

        return true;
    }
}
